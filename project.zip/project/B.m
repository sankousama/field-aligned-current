function [Bx By Bz] = B(Kp,TILT_ANGLE,x,y,z)
[Bx_ext By_ext Bz_ext]= T89(Kp,TILT_ANGLE,x,y,z); 
[Bx_dip By_dip Bz_dip]= dipole(TILT_ANGLE,x,y,z);
Bx= Bx_ext+Bx_dip;
By= By_ext+By_dip;
Bz= Bz_ext+Bz_dip;
end

