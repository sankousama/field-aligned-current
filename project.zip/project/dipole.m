function [BX,BY,BZ] = dipole (TILT_ANGLE,X,Y,Z);
%function [BX,BY,BZ] = dipole (X,Y,Z)
%       SUBROUTINE DIP (X,Y,Z,BX,BY,BZ)
% C
% C  CALCULATES XYZ COMPONENTS OF A GEODIPOLE FIELD WITH THE DIPOLE MOMENT
% C  CORRESPONDING TO THE EPOCH, SPECIFIED BY CALLING SUBROUTINE RECALC (SHOULD BE
% C  INVOKED BEFORE THE FIRST USE OF THIS ONE AND IN CASE THE DATE/TIME WAS CHANGED).
% C
% C--INPUT PARAMETERS: X,Y,Z -  COORDINATES IN UNITS of RE
% C                    TILT_ANGLE, dipole field tilt angle in degree, but
% C                                 set to zero for this project
% C
% C--OUTPUT PARAMETERS: BX,BY,BZ - FIELD COMPONENTS , IN NANOTESLA.
% C
% C  LAST MODIFICATION: MARCH 31, 2003
% C
% C  AUTHOR: N. A. TSYGANENKO

% C  Modified by Jian Yang

TILT_ANGLE=0.0;    % TILT_ANGLE is set to zero


DIPMOM=30574.0;
SPS=sin(TILT_ANGLE*pi/180.0);
CPS=cos(TILT_ANGLE*pi/180.0);

P=X^2;
U=Z^2;
V=3.*Z*X;
T=Y^2;
R=sqrt(P+U+T);
if (R<1.0) 
BX=0.0;
BY=0.0;
BZ=-2.0*DIPMOM;
else
Q=DIPMOM/sqrt(P+T+U)^5;
BX=Q*((T+U-2.*P)*SPS-V*CPS);
BY=-3.*Y*Q*(X*SPS+Z*CPS);
BZ=Q*((P+T-2.*U)*CPS-V*SPS);
end
%      RETURN
%      END
% end of function DIP
% C*******************************************************************
% c

