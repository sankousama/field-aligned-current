function p = P (X,Y);
% ����
a= 2.97*10^(-7);
b= 0.943;
c= 2.96*10^(-8);
d= 1.70;

r= (X^2+Y^2)^0.5;% ���ľ���
if r>3
    p= (10^9)*a*exp(-b*abs(r))+c*abs(r)^(-d);
else
    p= (10^9)*a*exp(-3*b)+c*3^(-d);
end
end

