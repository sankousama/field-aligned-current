% computeV - Function to compute V(x,y)
function [Bix Biy Biz Bx By Bz v,L]=computeV(xi,yi,ke,method)
    v=0;
    Kp=0;
    TILT_ANGLE=0;
    h=0.1; %����ռ䲽��
    istep=200; %����������д���
    zi=ke;
    r1(1,1:3)=[xi,yi,zi]; %�����ʼλ��
    for i=1:istep
        [Bx(i) By(i) Bz(i)]= B(Kp,TILT_ANGLE,r1(i,1),r1(i,2),r1(i,3));% ���㳡ǿ
        Bk=[Bx(i),By(i),Bz(i)]; %(x,y,z)���ĳ�ǿ
        Bm=norm(Bk); %(x,y,z)���ĳ�ǿ��С
        
        if(method== 1)%ŷ��
            r1(i+1,:)=r1(i,:)+h*Bk/Bm; %������r��ֵ
        end
        
        if(method==2)%RK4
            B_x=Bx(i);
            B_y=By(i);
            B_z=Bz(i);
            half_h = 0.5*h;
            
            F1=Bk/Bm;
            r1(i+1,:)=r1(i,:)+half_h*F1;
            [Bx(i) By(i) Bz(i)]= B(Kp,TILT_ANGLE,r1(i+1,1),r1(i+1,2),r1(i+1,3));% ���㳡ǿ
             Bk=[Bx(i),By(i),Bz(i)]; %(x,y,z)���ĳ�ǿ
             Bm=norm(Bk); %(x,y,z)���ĳ�ǿ��С
             
            F2=Bk/Bm;
            r1(i+1,:)=r1(i,:)+half_h*F2;
            [Bx(i) By(i) Bz(i)]= B(Kp,TILT_ANGLE,r1(i+1,1),r1(i+1,2),r1(i+1,3));% ���㳡ǿ
             Bk=[Bx(i),By(i),Bz(i)]; %(x,y,z)���ĳ�ǿ
             Bm=norm(Bk); %(x,y,z)���ĳ�ǿ��С
             
            F3=Bk/Bm;
            r1(i+1,:)=r1(i,:)+half_h*F3;
            [Bx(i) By(i) Bz(i)]= B(Kp,TILT_ANGLE,r1(i+1,1),r1(i+1,2),r1(i+1,3));% ���㳡ǿ
             Bk=[Bx(i),By(i),Bz(i)]; %(x,y,z)���ĳ�ǿ
             Bm=norm(Bk); %(x,y,z)���ĳ�ǿ��С
            F4=Bk/Bm;
            
            r1(i+1,:) = r1(i,:) + h/6.*(F1 + F4 + 2.*(F2+F3)); 
            Bx(i)= B_x;
            By(i)= B_y;
            Bz(i)= B_z;
        end

        
        if(norm(r1(i+1,:))<65/64)
            syms x y z
            x1= r1(i,1);
            x2= r1(i+1,1);
            y1= r1(i,2);
            y2= r1(i+1,2);
            z1= r1(i,3);
            z2= r1(i+1,3);
            [sx,sy,sz]=solve([x^2+y^2+z^2==1,(x-x1)/(x2-x1)== (y-y1)/(y2-y1),(z-z1)/(z2-z1)== (y-y1)/(y2-y1),(x-x1)/(x2-x1)== (z-z1)/(z2-z1)],[x,y,z]);
            if(length(sx)== 2)
                if(sx(1)>x1 && x2>sx(1))
                r1(i+1,:)= [sx(1),sy(1),sz(1)];
                elseif(sx(1)<x1 && x2<sx(1))
                r1(i+1,:)= [sx(1),sy(1),sz(1)];
                else
                r1(i+1,:)= [sx(2),sy(2),sz(2)];
                end
            elseif(length(sx)==1)
                r1(i+1,:)= [sx,sy,sz];
            end
            [Bix Biy Biz]= B(Kp,TILT_ANGLE,r1(i+1,1),r1(i+1,2),r1(i+1,3));% ���㳡ǿ
            t=1;
            break 
        else
            t=2;
        end
        
        v=v+norm(r1(i+1,:)-r1(i,:))/Bm; %����v��ֵ
    end
    L= length(Bx);
    if(t==2)
        [Bix Biy Biz]= B(Kp,TILT_ANGLE,r1(istep+1,1),r1(istep+1,2),r1(istep+1,3));% ���㳡ǿ
    end
    Bx= Bx(1);
    By= By(1);
    Bz= Bz(1);
end